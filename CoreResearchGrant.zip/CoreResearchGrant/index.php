<!DOCTYPE html>
<html>
<head>
    <title></title>
    <?php include 'links/links.php' ; ?>
    <?php include 'css/style.php' ; ?>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light nav_style p-3" >
        <a class="navbar-brand pl-5" href="#">
            <img src="images/logo.png" height="30" alt="logo" ></img>
            Core Research Grant
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto pr-5 text-capitalize">
                <li class="nav-item active">
                    <a class="nav-link" href="#homeid">home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#aboutid">about</a>
                </li>  
                <li class="nav-item">
                    <a class="nav-link" href="#">notices</a>
                </li> 
                <li class="nav-item">
                    <a class="nav-link" href="#">LogIn</a>
                </li> 
                <div class="dropdown">
                    <button class="btn dropdown-toggle" type="button" id="btnDropdownDemo" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Log In/Sign Up
                    </button>
                    <div class="dropdown-menu" aria-labelledby="btnDropdownDemo">
                        <a class="dropdown-item" href="https://www.jquery-az.com/bootstrap-4/">Applicant</a>
                        <a class="dropdown-item" href="https://www.jquery-az.com/jquery-tips/">Admin</a>
                        <a class="dropdown-item" href="https://www.jquery-az.com/html-tutorials/">Expert</a>
                    </div>
                </div>  
            </ul>
        </div>
    </nav>

    <div class="whole_front">

        <!-- about section  -->
        <div class="container-fluid sub_section pt-5 pb-5 " id="aboutid">
            <div class="section_header text-center mb-5 mt-4">
                <h1>What is Core Research Grant</h1>
            </div>
            <div class="row pt-5">
                <div class="col-lg-6 col-md-6 col-12">
                    <h2>About</h2>
                    <p>
                        write about here... 
                    </p>
                </div>
            </div>
        </div>

        <!-- notice panel on right -->
        <div class="notices_panel">
            <div class="card text-white bg-info">
                <div class="card-header">Notices</div>
                <div class="card-body">
                    <h4 class="card-title">Recent Notifications</h4>
                    <p class="card-text">Show notifications here</p>
                </div>
            </div>
        </div>    
    </div>
</body>
</html>