<style type="text/css">

html {
  scroll-behavior: smooth;
}

*{ margin: 0; padding: 0; box-sizing: border-box; font-family: 'Mulish', sans-serif; }

.whole_front {
  display: flex;
  justify-content: space-evenly;
}

.container-fluid {
  flex: 0.8;
}

.notices_panel{
    padding: 10px;
}
.card {
    background-color:  #007474!important;
}

.nav_style{
    background-color: #007474 !important;
}
.nav_style a{ color: white !important; }    

.nav_style button{ color: white !important; }

.navbar .dropdown-menu {
    background-color: #007474 !important; }



</style>